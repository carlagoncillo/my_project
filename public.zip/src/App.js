import './App.css';
import FirstClass from './components/first';

function App() {
  return (
    <div>
      <FirstClass/>
    </div> 
  );
}

export default App;
